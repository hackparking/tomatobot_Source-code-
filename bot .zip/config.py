import os
from dotenv import load_dotenv

# 環境変数を読み込む
load_dotenv()

TOKEN = os.getenv("DISCORD_BOT_TOKEN")
