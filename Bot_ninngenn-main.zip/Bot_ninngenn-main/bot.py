import os
import discord
from discord import app_commands
from discord.ext import commands
import asyncio
import config  # 設定ファイルからトークンを取得
from flask import Flask
from threading import Thread

# ✅ Discord Bot の設定
intents = discord.Intents.default()
intents.messages = True
intents.guilds = True
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

# ✅ Bot の起動時処理
@bot.event
async def on_ready():
    print(f"✅ {bot.user} がログインしました！")
    try:
        synced = await bot.tree.sync()
        print(f"✅ スラッシュコマンドが同期されました ({len(synced)})")
    except Exception as e:
        print(f"⚠️ スラッシュコマンドの同期に失敗しました: {e}")

# ✅ `/ping` - Botの応答速度を測定
@bot.tree.command(name="ping", description="Botの応答速度を測定します。")
async def ping(interaction: discord.Interaction):
    latency = round(bot.latency * 1000)  # ミリ秒単位
    await interaction.response.send_message(f"🏓 Pong! 応答速度: {latency}ms")

# ✅ `/ban` - 指定ユーザーをBAN
@bot.tree.command(name="ban", description="指定したユーザーをBANします。")
@app_commands.describe(user="BANするユーザー", reason="BANの理由")
async def ban(interaction: discord.Interaction, user: discord.Member, reason: str = "なし"):
    if interaction.user.guild_permissions.ban_members:
        await user.ban(reason=reason)
        await interaction.response.send_message(f"🚫 {user.mention} をBANしました。理由: {reason}")
    else:
        await interaction.response.send_message("❌ あなたにはBAN権限がありません。", ephemeral=True)

# ✅ `/timeout` - 指定ユーザーを一定時間ミュート
from datetime import timedelta

@bot.tree.command(name="timeout", description="指定したユーザーを一定時間ミュートします。")
@app_commands.describe(user="タイムアウトするユーザー", minutes="ミュートする時間（分）")
async def timeout(interaction: discord.Interaction, user: discord.Member, minutes: int):
    if interaction.user.guild_permissions.moderate_members:
        duration = timedelta(minutes=minutes)  # 修正：discord.utils.timedelta を datetime.timedelta に変更
        await user.timeout(duration)
        await interaction.response.send_message(f"⏳ {user.mention} を {minutes} 分間タイムアウトしました。")
    else:
        await interaction.response.send_message("❌ あなたにはタイムアウト権限がありません。", ephemeral=True)


# ✅ `/userinfo` - ユーザーのプロフィール情報を表示（プロフィール画像付き）
@bot.tree.command(name="userinfo", description="指定したユーザーの情報を表示します。")
@app_commands.describe(user="情報を確認するユーザー")
async def userinfo(interaction: discord.Interaction, user: discord.Member):
    embed = discord.Embed(title=f"{user.name} の情報", color=discord.Color.blue())
    embed.add_field(name="ID", value=user.id, inline=False)
    embed.add_field(name="ニックネーム", value=user.display_name, inline=False)
    embed.add_field(name="アカウント作成日", value=user.created_at.strftime("%Y-%m-%d %H:%M:%S"), inline=False)
    embed.add_field(name="サーバー参加日", value=user.joined_at.strftime("%Y-%m-%d %H:%M:%S"), inline=False)

    # プロフィール画像を追加
    avatar_url = user.avatar.url if user.avatar else user.default_avatar.url
    embed.set_thumbnail(url=avatar_url)

    await interaction.response.send_message(embed=embed)

# ✅ `/serverinfo` - サーバー情報を表示
@bot.tree.command(name="serverinfo", description="このサーバーの情報を表示します。")
async def serverinfo(interaction: discord.Interaction):
    guild = interaction.guild
    embed = discord.Embed(title=f"サーバー情報: {guild.name}", color=discord.Color.green())
    embed.add_field(name="サーバーID", value=guild.id, inline=False)
    embed.add_field(name="作成日", value=guild.created_at.strftime("%Y-%m-%d %H:%M:%S"), inline=False)
    embed.add_field(name="メンバー数", value=guild.member_count, inline=False)
    embed.set_thumbnail(url=guild.icon.url if guild.icon else None)

    await interaction.response.send_message(embed=embed)


# ✅ Flask 偽サーバー (Render のポート問題を回避)
app = Flask(__name__)

@app.route('/')
def home():
    return "Bot is running!"

def run_flask():
    port = int(os.environ.get("PORT", 8080))  # Render は 10000以上のポートを開くことができない
    app.run(host="0.0.0.0", port=port)

# ✅ Flask を別スレッドで実行しながら Discord Bot を起動
if __name__ == "__main__":
    # Flask サーバー (偽ポート)
    flask_thread = Thread(target=run_flask)
    flask_thread.start()

    # Discord Bot を実行
    bot.run(config.TOKEN)
