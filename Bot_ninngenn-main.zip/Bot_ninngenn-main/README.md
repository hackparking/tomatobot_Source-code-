# Discord Bot

## 使い方

### 1. セットアップ
```sh
git clone https://github.com/あなたのGitHubユーザー名/discord-bot.git
cd discord-bot
pip install -r requirements.txt
```


